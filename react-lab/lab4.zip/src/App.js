
import './App.css';

import Headers from "./Components/Header";
import Navigation from './Components/Navigation';
import Carousel from './Components/Carousel';
import Footer from "./Components/Footer";
import IndexBody from './Components/Body/IndexBody';
// import RecentlyAdded from './Components/RecentlyAdded'

function App() {
  return (
    <>
    <Headers />
    <Navigation />
    <Carousel />
    <IndexBody />
    <Footer />
</>
  );
}

export default App;
