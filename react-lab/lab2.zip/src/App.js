import './App.css';
import Addition from './components/Addition';
import Navigation from './components/Navigation';
import Subtraction from './components/Subtraction';

function App() {
  return (
    <>
      <Navigation />
      <Addition />
      <Subtraction />
    </>
  );
}

export default App;
