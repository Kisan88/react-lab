import "../assets/css/navigation.css"

function Navigation(){
   return(
    <>
        <ul className="nav">
            <li>
                <a href="">Home</a>
            </li>
            <li>
                <a href="">Product</a>
            </li>
            <li>
                <a href="">Cats</a>
            </li>
        </ul>
    </>
   )
}

export default Navigation;