import { useState } from "react";

function Subtraction() {

    const [firstName, setFirstName] = useState("Kisan");
    const [result, setResult] = useState(null);

    const x = 0;
    const y = 0;

    function updateX(e){
       let value = e.target.value;
       x = parseInt(value);
    }

    function updateY(e){
       let value = e.target.value;
       y = parseInt(value);
    }

    function calResult(){
        setResult(x-y);
    }

    return (
        <div>
            <h1>My Subtraction </h1>
            <h3>My Name is {firstName}</h3>
            <input onChange={updateX}/>
            <input onChange={updateY}/>
            <button onClick={calResult}>
                Submit
            </button>
            <pre>
                Result is { result }
            </pre>
        </div>
    )


}
export default Subtraction;