import { useState } from "react";

function Addition() {

    // Reactive Variables 
    const [firstName, setfirstName] = useState('kisan');
    const [result, setResult] = useState(null);
    const [x, setX] = useState(null);
    const [y, sety] = useState(null);
    // Normal Variables 
    

    // Not a reactive variable in react 
    // let result = 0; 

    function updateX(e) {
        console.log(e);
        
        const target = e.target
        const value = target.value
        console.log(value)
        setX(parseInt(value));

    }

    function updateY(e) {
        
        const target = e.target
        const value = target.value
        console.log(value)
        sety(parseInt(value));
    }

    function _calResult() {
        setResult(x + y);

    }

    return (
        <div>
            <h1>My Addition</h1>
            <h3>My Name is {firstName} </h3>
            <input
                onChange={updateX}
            />
            <input
                onChange={updateY}
            />
            <button
                onClick={_calResult}
            >
                Submit
            </button>
            <pre>
                Result is {result}
            </pre>
        </div>
    )


}
export default Addition;