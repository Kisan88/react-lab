import './App.css';
import { Dashboard } from './components/Dashboard';
import Navigation from './components/Navigation';
import { ContactPage } from './pages/ContactPage';
import HomePage from './pages/HomePage';
import {Routes, Route} from 'react-router-dom';
import LoginPage from './components/Login'
import DashboardPage from './pages/DashboardPage';

function App() {

  const firstName = 'Kisan';
  return (
    <Routes>
      
      <Route exact path='/' element={<HomePage />} />
      <Route exact path='/contact' element={<ContactPage />} />
      <Route exact path='/login' element={<LoginPage />} />
      <Route exact path='/dashboard' element={<DashboardPage />} />
    </Routes>
  );
}

export default App;
