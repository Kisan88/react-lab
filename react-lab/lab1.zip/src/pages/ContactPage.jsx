import React from 'react'
import Navigation from '../components/Navigation'

export const ContactPage = () => {
  return (
    <>
        <Navigation />
        <h1>This is a contact page</h1>
    </>
  )
}
