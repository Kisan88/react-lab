import React from 'react'
import Login from '../components/Login'

export const LoginPage = () => {
  return (
    <>
        <Navigation />
        <div>
            <Login />
        </div>
    </>
    
  )
}
