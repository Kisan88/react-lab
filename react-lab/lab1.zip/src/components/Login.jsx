import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

const Login = () => {

    const loginStatus = false;
    const navigate = useNavigate()

    useEffect(() =>{
        if(loginStatus){
            navigate('/dashboard')
        }else{
            navigate('/login')
        }
    })
  return (
    <div>
        <h1>I am Login</h1>
    </div>
  )
}

export default Login