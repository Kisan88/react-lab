import React from 'react'

export const Dashboard = () => {
  return (
    <div>Dashboard</div>
  )
}
