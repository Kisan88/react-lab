import React, {useState} from 'react'

const Employee = () => {

    const [firstName, setFirstName] = useState(null);
  return (
    <div>
        <h1>Employee name is { firstName }</h1>
        <input onChange={(e) => setFirstName(e.target.value)} type='text'/>
    </div>
  )
}

export default Employee