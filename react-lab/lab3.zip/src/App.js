
import './App.css';
import SignUpForm from './components/SignUpForm';

function App() {
  return (
    <>
      <SignUpForm />
    </>
  );
}

export default App;
